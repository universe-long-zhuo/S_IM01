package org.yuner.www.commons;

public class GlobalErrors {
	
	public static int nameAlreadyExists = -10;
	public static int nameDoesnotExists = -16;
}
