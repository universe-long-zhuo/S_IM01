/** Automatically generated file. DO NOT MODIFY */
package org.yuner.www;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}