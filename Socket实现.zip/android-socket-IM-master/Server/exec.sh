java -classpath $CLASSPATH:/usr/share/java/mysql-connector-java.jar:bin org/yuner/www/ServerListen
