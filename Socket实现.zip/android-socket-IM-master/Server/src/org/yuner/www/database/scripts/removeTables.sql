use my_IM_GGMM;
drop table if exists friendListTable;
drop table if exists userTable;
