package org.yuner.www.commons;

public class GlobalInts {

	public static final int idPlaceholder = -100;

	public static final int idNotOnline = 21;
	public static final int idRefuseFriendship = 22;
	public static final int idAcceptFriendship = 23;

}
