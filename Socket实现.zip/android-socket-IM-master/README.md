android-socket-IM
=================

this is a android instant messenger based on socket communication

basic functionality:

1. a user can register an account with a username, his/her age and gender
2. login with username and password
3. find out friends by username or particulars(age and gender)
4. chat with a friend with text and emoji
5. chatting history available for checking
6. messages sent to offline friends will be saved at server and pushed to that friend when he/she signs in
7. ringtone and vibration notification when a message arrived if messanger is not foreground
